from flask import Flask, render_template, request, jsonify
import pickle
import re
from urllib.parse import urlparse

app = Flask(__name__)

# Load the model and vectorizer
try:
    model = pickle.load(open('models/spam_model.pkl', 'rb'))
    vectorizer = pickle.load(open('models/vectorizer.pkl', 'rb'))
    print("Model loaded successfully!")
except:
    print("Please run model_training.py first!")
    model = None
    vectorizer = None

def extract_urls(text):
    """Extract URLs from text"""
    url_pattern = re.compile(r'https?://[^\s]+|www\.[^\s]+|[^\s]+\.[^\s]+')
    return url_pattern.findall(text)

def check_email_id(email):
    """Check if email ID is suspicious"""
    # Simple pattern for email validation
    email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    if not email_pattern.match(email):
        return {"is_valid": False, "message": "Invalid email format"}
    
    # Check for suspicious domains
    suspicious_domains = ['temp-mail.org', 'guerrillamail.com', '10minutemail.com']
    domain = email.split('@')[-1] if '@' in email else ''
    
    if domain in suspicious_domains:
        return {"is_valid": True, "is_suspicious": True, "message": "Temporary email domain detected"}
    
    return {"is_valid": True, "is_suspicious": False, "message": "Email ID appears normal"}

def scan_url(url):
    """Scan URL for suspicious patterns"""
    suspicious_patterns = [
        r'bit\.ly', r'tinyurl', r'goo\.gl', r'ow\.ly',  # URL shorteners
        r'login', r'signin', r'account', r'verify',      # Suspicious keywords
        r'secure', r'update', r'confirm',                # More keywords
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'            # IP addresses
    ]
    
    threats = []
    for pattern in suspicious_patterns:
        if re.search(pattern, url, re.IGNORECASE):
            threats.append(f"Contains suspicious pattern: {pattern}")
    
    return {
        "is_suspicious": len(threats) > 0,
        "threats": threats,
        "message": "Suspicious URL detected" if threats else "URL appears normal"
    }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan():
    data = request.json
    scan_type = data.get('type')
    content = data.get('content')
    
    if not content:
        return jsonify({"error": "No content provided"})
    
    result = {"type": scan_type, "content": content}
    
    if scan_type == 'email_scanner':
        # Scan email content
        if model and vectorizer:
            # Vectorize and predict
            content_vectorized = vectorizer.transform([content])
            prediction = model.predict(content_vectorized)[0]
            probability = model.predict_proba(content_vectorized)[0]
            
            result.update({
                "is_spam": bool(prediction),
                "confidence": float(max(probability)),
                "message": "Spam detected!" if prediction else "This appears to be legitimate"
            })
        else:
            # Simple rule-based detection as fallback
            spam_keywords = ['win', 'prize', 'lottery', 'congratulations', 'free', 'money', 'claim']
            content_lower = content.lower()
            keyword_matches = [kw for kw in spam_keywords if kw in content_lower]
            
            result.update({
                "is_spam": len(keyword_matches) > 0,
                "keyword_matches": keyword_matches,
                "message": "Suspicious keywords found" if keyword_matches else "No spam indicators found"
            })
    
    elif scan_type == 'text_scanner':
        # Scan text message
        if model and vectorizer:
            content_vectorized = vectorizer.transform([content])
            prediction = model.predict(content_vectorized)[0]
            probability = model.predict_proba(content_vectorized)[0]
            
            result.update({
                "is_spam": bool(prediction),
                "confidence": float(max(probability)),
                "message": "Spam detected!" if prediction else "This text appears legitimate"
            })
        else:
            spam_keywords = ['urgent', 'claim', 'winner', 'prize', 'free', 'cash']
            content_lower = content.lower()
            keyword_matches = [kw for kw in spam_keywords if kw in content_lower]
            
            result.update({
                "is_spam": len(keyword_matches) > 0,
                "keyword_matches": keyword_matches,
                "message": "Suspicious keywords found" if keyword_matches else "No spam indicators found"
            })
    
    elif scan_type == 'email_id_checker':
        # Check email ID
        result.update(check_email_id(content))
    
    elif scan_type == 'url_scanner':
        # Scan URL
        result.update(scan_url(content))
    
    else:
        return jsonify({"error": "Invalid scan type"})
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)