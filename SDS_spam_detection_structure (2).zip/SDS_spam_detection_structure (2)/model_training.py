import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report
import os

# Create models directory if it doesn't exist
if not os.path.exists('models'):
    os.makedirs('models')

# Load the dataset (assuming you have spam.csv)
# If you don't have it, you can download from: https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset
try:
    df = pd.read_csv('spam.csv', encoding='latin-1')
    # Keep only the necessary columns
    df = df[['v1', 'v2']]
    df.columns = ['label', 'message']
except:
    # Sample data if file doesn't exist
    print("Creating sample data...")
    data = {
        'label': ['ham', 'spam', 'ham', 'spam', 'ham', 'spam', 'ham', 'ham', 'spam', 'ham'],
        'message': [
            'Hello, how are you?',
            'Congratulations! You won a lottery! Claim now',
            'Meeting at 3pm tomorrow',
            'FREE MONEY! Click here to claim your prize',
            'Can you pick up some groceries?',
            'URGENT: Your account has been compromised',
            'See you at the party tonight',
            'Don\'t forget to bring the documents',
            'WINNER! You have been selected for a prize',
            'Lunch at 12?'
        ]
    }
    df = pd.DataFrame(data)

# Convert labels to binary (spam=1, ham=0)
df['label'] = df['label'].map({'spam': 1, 'ham': 0})

# Split the data
X_train, X_test, y_train, y_test = train_test_split(
    df['message'], df['label'], test_size=0.2, random_state=42
)

# Create and fit the vectorizer
vectorizer = CountVectorizer(stop_words='english', max_features=5000)
X_train_vectorized = vectorizer.fit_transform(X_train)
X_test_vectorized = vectorizer.transform(X_test)

# Train the model
model = MultinomialNB()
model.fit(X_train_vectorized, y_train)

# Evaluate the model
y_pred = model.predict(X_test_vectorized)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy:.2f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Ham', 'Spam']))

# Save the model and vectorizer
pickle.dump(model, open('models/spam_model.pkl', 'wb'))
pickle.dump(vectorizer, open('models/vectorizer.pkl', 'wb'))

print("\nModel and vectorizer saved successfully!")