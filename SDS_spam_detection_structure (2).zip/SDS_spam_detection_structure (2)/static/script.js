document.addEventListener('DOMContentLoaded', function() {
    const scannerCards = document.querySelectorAll('.scanner-card');
    const scanBtn = document.getElementById('scan-btn');
    const inputContent = document.getElementById('input-content');
    const resultContainer = document.getElementById('result-container');
    const resultContent = document.getElementById('result-content');
    
    let currentScanType = 'email_scanner';
    
    // Scanner type selection
    scannerCards.forEach(card => {
        card.addEventListener('click', function() {
            scannerCards.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            currentScanType = this.dataset.type;
            
            // Update placeholder based on scanner type
            updatePlaceholder(currentScanType);
        });
    });
    
    function updatePlaceholder(type) {
        const placeholders = {
            'email_scanner': 'Enter email content to scan for spam...',
            'text_scanner': 'Enter text message to analyze...',
            'email_id_checker': 'Enter email address to check (e.g., user@example.com)...',
            'url_scanner': 'Enter URL to scan (e.g., https://example.com)...'
        };
        inputContent.placeholder = placeholders[type] || 'Enter content to scan...';
    }
    
    // Scan button click
    scanBtn.addEventListener('click', function() {
        const content = inputContent.value.trim();
        
        if (!content) {
            alert('Please enter content to scan');
            return;
        }
        
        // Show loading state
        scanBtn.disabled = true;
        scanBtn.textContent = 'Scanning...';
        
        // Make API request
        fetch('/scan', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                type: currentScanType,
                content: content
            })
        })
        .then(response => response.json())
        .then(data => {
            displayResults(data);
        })
        .catch(error => {
            console.error('Error:', error);
            resultContent.innerHTML = '<div class="result-item warning">An error occurred while scanning. Please try again.</div>';
            resultContainer.style.display = 'block';
        })
        .finally(() => {
            scanBtn.disabled = false;
            scanBtn.textContent = 'Scan Now';
        });
    });
    
    function displayResults(data) {
        let html = '';
        
        if (data.error) {
            html = `<div class="result-item warning">Error: ${data.error}</div>`;
        } else {
            switch(data.type) {
                case 'email_scanner':
                case 'text_scanner':
                    html = generateTextScanResult(data);
                    break;
                case 'email_id_checker':
                    html = generateEmailCheckResult(data);
                    break;
                case 'url_scanner':
                    html = generateURLScanResult(data);
                    break;
                default:
                    html = '<div class="result-item warning">Unknown scan type</div>';
            }
        }
        
        resultContent.innerHTML = html;
        resultContainer.style.display = 'block';
        
        // Scroll to results
        resultContainer.scrollIntoView({ behavior: 'smooth' });
    }
    
    function generateTextScanResult(data) {
        const isSpam = data.is_spam;
        const confidence = data.confidence ? (data.confidence * 100).toFixed(1) : null;
        const message = data.message || '';
        const keywords = data.keyword_matches || [];
        
        let html = `<div class="result-item ${isSpam ? 'spam' : 'ham'}">`;
        html += `<strong>Status:</strong> ${isSpam ? '⚠️ SPAM DETECTED' : '✅ LEGITIMATE'}<br>`;
        html += `<strong>Message:</strong> ${message}<br>`;
        
        if (confidence) {
            html += `<strong>Confidence:</strong> ${confidence}%<br>`;
            html += `<div class="confidence-bar"><div class="confidence-fill" style="width: ${confidence}%"></div></div>`;
        }
        
        if (keywords && keywords.length > 0) {
            html += `<strong>Suspicious keywords found:</strong><br>`;
            html += `<div class="keyword-list">`;
            keywords.forEach(kw => {
                html += `<span class="keyword-tag">${kw}</span>`;
            });
            html += `</div>`;
        }
        
        html += '</div>';
        return html;
    }
    
    function generateEmailCheckResult(data) {
        const isValid = data.is_valid;
        const isSuspicious = data.is_suspicious;
        const message = data.message || '';
        
        let resultClass = 'ham';
        if (!isValid) resultClass = 'warning';
        else if (isSuspicious) resultClass = 'spam';
        
        let html = `<div class="result-item ${resultClass}">`;
        html += `<strong>Email ID:</strong> ${data.content}<br>`;
        html += `<strong>Status:</strong> `;
        
        if (!isValid) {
            html += `❌ Invalid Format<br>`;
        } else if (isSuspicious) {
            html += `⚠️ Suspicious<br>`;
        } else {
            html += `✅ Valid<br>`;
        }
        
        html += `<strong>Message:</strong> ${message}<br>`;
        html += '</div>';
        
        return html;
    }
    
    function generateURLScanResult(data) {
        const isSuspicious = data.is_suspicious;
        const threats = data.threats || [];
        const message = data.message || '';
        
        let html = `<div class="result-item ${isSuspicious ? 'spam' : 'ham'}">`;
        html += `<strong>URL:</strong> ${data.content}<br>`;
        html += `<strong>Status:</strong> ${isSuspicious ? '⚠️ SUSPICIOUS' : '✅ SAFE'}<br>`;
        html += `<strong>Message:</strong> ${message}<br>`;
        
        if (threats && threats.length > 0) {
            html += `<strong>Threats detected:</strong><br>`;
            html += `<ul>`;
            threats.forEach(threat => {
                html += `<li>${threat}</li>`;
            });
            html += `</ul>`;
        }
        
        html += '</div>';
        return html;
    }
});